1.--Conteo de Usuarios: Elabore una consulta que permita contar el número total de usuarios registrados en la plataforma. Utilice la función COUNT

SELECT COUNT(*) AS total_usuarios
FROM usuario;

2.--Agrupación de Barrios por Comuna: Realice una consulta que muestre el nombre de la comuna y la cantidad de barrios asociados a cada una. Debe utilizar GROUP BY para agrupar por comuna y COUNT para contar los barrios.
SELECT
    comuna_barrio.comuna AS comuna,
    comuna_barrio.barrio AS barrio,
    COUNT(usuario.COMUNA_BARRIO_id) AS total
FROM
    usuario, comuna_barrio
WHERE
    comuna_barrio.id = usuario.COMUNA_BARRIO_id
GROUP BY
    usuario.COMUNA_BARRIO_id;

3.--Alias en Columnas (Juegos): Seleccione el nombre y el estudio desarrollador de todos los juegos. Renombre las columnas en el resultado como "Título del Juego" y "Empresa Desarrolladora" utilizando AS.
SELECT nombre AS "Título del Juego", 
       estudio_dev AS "Empresa Desarrolladora"
FROM juego;

4.--Unión Implícita (Usuarios y Barrios): Muestre el nombre completo del usuario (Primer Nombre y Primer Apellido) junto con el nombre del barrio en el que reside. Realice la unión entre las tablas USUARIO y COMUNA_BARRIO utilizando la cláusula WHERE (sin usar JOIN).
SELECT u.primer_nombre, u.primer_apellido, cb.barrio
FROM usuario u, comuna_barrio cb
WHERE u.COMUNA_BARRIO_id = cb.id;

5.--Conteo de Juegos por Plataforma: Genere una consulta que indique cuántos juegos hay registrados para cada plataforma (identificada por su PLATAFORMA_id). Utilice GROUP BY y COUNT.
SELECT PLATAFORMA_id, COUNT(*) AS cantidad_juegos
FROM juego
GROUP BY PLATAFORMA_id;

6.--Alias en Columnas (Equipos): Liste el nombre de los equipos y sus horas de entrenamiento. Asigne el alias "Squad" a la columna de nombre y "Tiempo Jugado" a la columna de horas.
SELECT nombre AS Squad, horas AS 'Tiempo Jugado'
FROM equipo_juego;

7.--Unión Implícita (Equipos y Juegos): Elabore una consulta que muestre el nombre del equipo y el nombre del juego en el que se especializa. Debe unir las tablas EQUIPO_JUEGO y JUEGO igualando sus claves foráneas y primarias en el WHERE.
SELECT eq.nombre AS nombre_equipo, j.nombre AS nombre_juego
FROM equipo_juego eq, juego j
WHERE eq.JUEGO_id = j.id

8.--Promedio de Existencias por Tipo de Juego: (Opcional: Si desean practicar AVG, sino usar COUNT) Alternativa con COUNT: Cuente cuántos juegos existen por cada "tipo" (ej. Shooter, MOBA, etc.). Muestre el tipo de juego y la cantidad.
SELECT tipo, COUNT(*) AS cantidad
FROM juego
GROUP BY tipo;

9.--Unión Implícita (Logros y Juegos): Liste los nombres de los logros/trofeos, los puntos requeridos y el nombre del juego al que pertenecen. Realice la unión entre LOGRO_TROFEO y JUEGO mediante WHERE.
SELECT lt.nombre AS nombre_logro, lt.puntos_req, j.nombre AS nombre_juego
FROM logro_trofeo lt, juego j
WHERE lt.JUEGO_id = j.id;

10.--Unión Implícita con Alias de Tabla (Sesiones y Árbitros): Muestre la fecha de la sesión de entrenamiento y el nombre del árbitro (que es un usuario). Una las tablas SESION_ENTRENAMIENTO y USUARIO usando WHERE. Intente usar alias para las tablas (ej. FROM SESION_ENTRENAMIENTO s, USUARIO u) para simplificar la condición del WHERE.
SELECT
U.primer_nombre,
SE.fecha_agenda
FROM
sesion_entrenamiento SE,usuario u
WHERE
SE.arbitro=u.id;